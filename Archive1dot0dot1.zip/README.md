# Birmingham Panopto Keeper
A simple extension for Google Chrome that allows you to download videos from Panopto for later viewing. Only works for the University of Birmingham.

HOW TO USE: Navigate to the Panopto video itself you want to download, click the download icon (next to your user picture) and choose where you want the video to be saved. 

NOTE: This will be updated/improved if and when I have time. I may work on a Firefox extension in the future.

Based on downloadPanopto by dfaour: https://github.com/dfaour/downloadPanopto

Released under GNU General License 3.0.
